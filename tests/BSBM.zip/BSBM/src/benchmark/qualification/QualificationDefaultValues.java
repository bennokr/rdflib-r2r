package benchmark.qualification;

public class QualificationDefaultValues {
	public static final boolean resultsCountOnly=false;
	public static final String qualificationLog = "qual.log";
}

CREATE TABLE "vendor" (
  "nr" int primary key,
  "label" varchar(100) default NULL,
  "comment" varchar(2000) default NULL,
  "homepage" varchar(100) default NULL,
  "country" char(2) ,
  "publisher" int,
  "publishDate" date
);

INSERT INTO "vendor" VALUES (1,'outreasons','canebrake tailored noncivilized teuton vined adsorptively electrocardiographs subbing mitigator squarest phosgenes gallinules collops redesigned doings purposing nictated birthmarks displayed chemical cottiers whoopee provocatively luffs accedence aliening ombudsmen','http://www.vendor1.com/','GB',1,'2008-05-31');
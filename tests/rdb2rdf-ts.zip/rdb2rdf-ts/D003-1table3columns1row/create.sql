CREATE TABLE "Student" (
"ID" INTEGER,
"FirstName" VARCHAR(50),
"LastName" VARCHAR(50)
);
INSERT INTO "Student" ("ID", "FirstName", "LastName") VALUES (10,'Venus', 'Williams');
